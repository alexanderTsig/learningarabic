<?php
 return array (
  ' at ' => ' at ',
  ' day' => ' day',
  '"Call Home" functionality - every .. days
software will periodically contact your site
to check activation and license status
enter 0 to disable' => '"Call Home" functionality - every .. days
software will periodically contact your site
to check activation and license status
enter 0 to disable',
  '# of users' => '# of users',
  '%d days after expiration' => '%d days after expiration',
  '%d days before expiration' => '%d days before expiration',
  '%d user(s) matches your search' => '%d user(s) matches your search',
  '%d-th day' => '%d-th day',
  '%d-th subscription day' => '%d-th subscription day',
  '%s Plugins' => '%s Plugins',
  '%url% will be replaced with actual url of affilate link' => '%url% will be replaced with actual url of affilate link',
  '- all old members become not-approved' => '- all old members become not-approved',
  '-- Please Select --' => '-- Please Select --',
  '-- Without A Category --' => '-- Without A Category --',
  '..th subscription day (starts from 2)' => '..th subscription day (starts from 2)',
  '100% discount' => '100% discount',
  '<p>For each item in purchase, aMember will look through all rules, from top to bottom. If it finds a matching multiplier, it will be remembered. If it finds a matching custom rule, it takes commission rates from it. If no matching custom rule was found, it uses "Default" commission settings.</p><p>For n-tier affiliates, no rules are used, you can just define percentage of commission earned by previous level.</p>' => '<p>For each item in purchase, aMember will look through all rules, from top to bottom. If it finds a matching multiplier, it will be remembered. If it finds a matching custom rule, it takes commission rates from it. If no matching custom rule was found, it uses "Default" commission settings.</p><p>For n-tier affiliates, no rules are used, you can just define percentage of commission earned by previous level.</p>',
  '<p>Message has been sent successfully. Please wait 2 minutes and check the mailbox <em>%s</em>.<br />There must be a message with subject [Test E-Mail]. Do not forget to check <em>Spam</em> folder.</p><p>If the message does not arrive shortly, contact your webhosting support and ask them to find <br />in <strong>mail.log</strong> what happened with a message sent from <em>%s</em> to <em>%s</em> at %s</p>' => '<p>Message has been sent successfully. Please wait 2 minutes and check the mailbox <em>%s</em>.<br />There must be a message with subject [Test E-Mail]. Do not forget to check <em>Spam</em> folder.</p><p>If the message does not arrive shortly, contact your webhosting support and ask them to find <br />in <strong>mail.log</strong> what happened with a message sent from <em>%s</em> to <em>%s</em> at %s</p>',
  'ACTIVE subscription for %s' => 'ACTIVE subscription for %s',
  'ACTIVE subscription for group %s' => 'ACTIVE subscription for group %s',
  'API Keys' => 'API Keys',
  'Accepted Payout Methods' => 'Accepted Payout Methods',
  'Access Method' => 'Access Method',
  'Account Sharing Prevention' => 'Account Sharing Prevention',
  'Account Verification' => 'Account Verification',
  'Action' => 'Action',
  'Active(free)' => 'Active(free)',
  'Add & Checkout' => 'Add & Checkout',
  'Add & Go to Basket' => 'Add & Go to Basket',
  'Add Access Manually' => 'Add Access Manually',
  'Add Chargeback' => 'Add Chargeback',
  'Add Child' => 'Add Child',
  'Add Invoice' => 'Add Invoice',
  'Add Invoice and Payment/Access Manually' => 'Add Invoice and Payment/Access Manually',
  'Add Payment' => 'Add Payment',
  'Add Payment Manually' => 'Add Payment Manually',
  'Add Pending Invoice and Send Link to Pay It to Customer' => 'Add Pending Invoice and Send Link to Pay It to Customer',
  'Add Refund' => 'Add Refund',
  'Add Report to My Dashboard' => 'Add Report to My Dashboard',
  'Add Root Node' => 'Add Root Node',
  'Add Signature to Response' => 'Add Signature to Response',
  'Add Subscription' => 'Add Subscription',
  'Add User Fields' => 'Add User Fields',
  'Add points to affiliate for each %s in payment' => 'Add points to affiliate for each %s in payment',
  'Add to Basket only' => 'Add to Basket only',
  'Added' => 'Added',
  'Additional' => 'Additional',
  'Additional Fields' => 'Additional Fields',
  'Additionally to "Access", add "Invoice" and "Payment" record with given %s amount, like they have really made a payment' => 'Additionally to "Access", add "Invoice" and "Payment" record with given %s amount, like they have really made a payment',
  'Admin Accounts' => 'Admin Accounts',
  'Admin E-Mail Address
used to send email notifications to admin
and as default outgoing address' => 'Admin E-Mail Address
used to send email notifications to admin
and as default outgoing address',
  'Admin Email' => 'Admin Email',
  'Admin Free Subscription Notifications
to admin once free signup is completed' => 'Admin Free Subscription Notifications
to admin once free signup is completed',
  'Admin Log' => 'Admin Log',
  'Admin Pages Theme' => 'Admin Pages Theme',
  'Admin Payment Notifications
to admin once payment is received' => 'Admin Payment Notifications
to admin once payment is received',
  'Admin Settings' => 'Admin Settings',
  'Admin Username' => 'Admin Username',
  'Admin notification' => 'Admin notification',
  'Admin username must be alphanumeric in small caps' => 'Admin username must be alphanumeric in small caps',
  'Administrator Login' => 'Administrator Login',
  'Administrator has been removed, id [%d]' => 'Administrator has been removed, id [%d]',
  'Advanced' => 'Advanced',
  'Advanced Settings' => 'Advanced Settings',
  'Affiliate %s not found' => 'Affiliate %s not found',
  'Affiliate Can View Sales Details' => 'Affiliate Can View Sales Details',
  'Affiliate Commission' => 'Affiliate Commission',
  'Affiliate Commission Details for' => 'Affiliate Commission Details for',
  'Affiliate Commission Rules' => 'Affiliate Commission Rules',
  'Affiliate Cookie Lifetime
days to store cookies about referred affiliate' => 'Affiliate Cookie Lifetime
days to store cookies about referred affiliate',
  'Affiliate Information' => 'Affiliate Information',
  'Affiliate Payout Conversion Rate
how many credits affiliate should recieve for %s' => 'Affiliate Payout Conversion Rate
how many credits affiliate should recieve for %s',
  'Affiliate Payout Paid Notification to User
send email to user when his payout is marked as paid' => 'Affiliate Payout Paid Notification to User
send email to user when his payout is marked as paid',
  'Affiliate Registration E-Mail' => 'Affiliate Registration E-Mail',
  'Affiliates Payout Day
choose a day of month when payout is generated' => 'Affiliates Payout Day
choose a day of month when payout is generated',
  'Affiliates Signup Type' => 'Affiliates Signup Type',
  'After making any changes to htpasswd protected areas, please run [Utiltites->Rebuild Db] to refresh htpasswd file' => 'After making any changes to htpasswd protected areas, please run [Utiltites->Rebuild Db] to refresh htpasswd file',
  'All Banners' => 'All Banners',
  'All Content' => 'All Content',
  'All Subscription Period' => 'All Subscription Period',
  'All new users automatically become affiliates' => 'All new users automatically become affiliates',
  'Allow Affiliates to redirect Referrers to any url' => 'Allow Affiliates to redirect Referrers to any url',
  'Allow Redirects to Other Domains
By default aMember does not allow to redirect to foreign domain names via \'amember_redirect_url\' parameter.
These redirects are only allowed for urls within your domain name.
This is restricted to avoid potential security issues.
' => 'Allow Redirects to Other Domains
By default aMember does not allow to redirect to foreign domain names via \'amember_redirect_url\' parameter.
These redirects are only allowed for urls within your domain name.
This is restricted to avoid potential security issues.
',
  'Allow for some affiliates, disallow for others' => 'Allow for some affiliates, disallow for others',
  'Allow to Use Password Hash from 3ty part Scripts to Authenticate User in aMember' => 'Allow to Use Password Hash from 3ty part Scripts to Authenticate User in aMember',
  'Allowed E-Mails Count
enter number of emails allowed within the period above' => 'Allowed E-Mails Count
enter number of emails allowed within the period above',
  'Allowed E-Mails Period
choose if your host is limiting e-mails per day or per hour' => 'Allowed E-Mails Period
choose if your host is limiting e-mails per day or per hour',
  'Always Remember
if set to Yes, don\'t ask customer - always remember' => 'Always Remember
if set to Yes, don\'t ask customer - always remember',
  'Amazon SES' => 'Amazon SES',
  'Amazon SES Access Id' => 'Amazon SES Access Id',
  'Amazon SES Region' => 'Amazon SES Region',
  'Amazon SES Secret Key' => 'Amazon SES Secret Key',
  'American Date Format' => 'American Date Format',
  'Api Key' => 'Api Key',
  'Apply Tax?' => 'Apply Tax?',
  'Apply to recurring?
apply coupon discount to recurring rebills?' => 'Apply to recurring?
apply coupon discount to recurring rebills?',
  'Approve' => 'Approve',
  'Assign Category' => 'Assign Category',
  'At least one billing plan must be added' => 'At least one billing plan must be added',
  'Authentification' => 'Authentification',
  'Auto Buffering' => 'Auto Buffering',
  'Auto Play' => 'Auto Play',
  'Auto-generated Template Settings' => 'Auto-generated Template Settings',
  'Autoclose Tickets Due to Inactivity' => 'Autoclose Tickets Due to Inactivity',
  'Automatically Login Customer After Signup' => 'Automatically Login Customer After Signup',
  'Autoresponder message will be automatically sent by cron job
when configured conditions met. If you set message to be sent
after payment, it will be sent immediately after payment received.
Auto-responder message will not be sent if:
<ul>
    <li>User has unsubscribed from e-mail messages</li>
</ul>' => 'Autoresponder message will be automatically sent by cron job
when configured conditions met. If you set message to be sent
after payment, it will be sent immediately after payment received.
Auto-responder message will not be sent if:
<ul>
    <li>User has unsubscribed from e-mail messages</li>
</ul>',
  'Available' => 'Available',
  'Available Locales
defines both language and date/number formats' => 'Available Locales
defines both language and date/number formats',
  'Available Products' => 'Available Products',
  'Available Upgrades' => 'Available Upgrades',
  'Available for users from groups' => 'Available for users from groups',
  'BCC' => 'BCC',
  'BEGIN' => 'BEGIN',
  'Back to Dashboard' => 'Back to Dashboard',
  'Back to FAQ List' => 'Back to FAQ List',
  'Backup' => 'Backup',
  'Backup can be runned by POST request only' => 'Backup can be runned by POST request only',
  'Backup file header' => 'Backup file header',
  'Banner' => 'Banner',
  'Banner Categories' => 'Banner Categories',
  'Banners' => 'Banners',
  'Base' => 'Base',
  'Base Currency
base currency to be used for reports and affiliate commission.
It could not be changed if there are any invoices in database.
You can edit exchange rate %shere%s' => 'Base Currency
base currency to be used for reports and affiliate commission.
It could not be changed if there are any invoices in database.
You can edit exchange rate %shere%s',
  'Basket HTML Code' => 'Basket HTML Code',
  'Begin date should be before Expire date' => 'Begin date should be before Expire date',
  'Billing' => 'Billing',
  'Billing Terms' => 'Billing Terms',
  'Bind To
activation will be tied to the following installation parameters
usually 1 choice is quite enough' => 'Bind To
activation will be tied to the following installation parameters
usually 1 choice is quite enough',
  'Blob (unlimited length binary data)' => 'Blob (unlimited length binary data)',
  'Block This IP Address' => 'Block This IP Address',
  'Blocking IP/E-Mail' => 'Blocking IP/E-Mail',
  'Briefly unavailable for scheduled maintenance. Check back in a minute.' => 'Briefly unavailable for scheduled maintenance. Check back in a minute.',
  'Browse' => 'Browse',
  'Browse Countries' => 'Browse Countries',
  'Browse Found Users' => 'Browse Found Users',
  'Browse States' => 'Browse States',
  'Browse Users' => 'Browse Users',
  'Bruteforce Notification
notify admin when bruteforce attack is detected' => 'Bruteforce Notification
notify admin when bruteforce attack is detected',
  'Bruteforce Protection' => 'Bruteforce Protection',
  'Buffer Length' => 'Buffer Length',
  'Build Demo' => 'Build Demo',
  'Building demo records' => 'Building demo records',
  'Button/Link HTML Code' => 'Button/Link HTML Code',
  'By default each invoice will be set as "Not Approved" ' => 'By default each invoice will be set as "Not Approved" ',
  'CONTINUE' => 'CONTINUE',
  'Calculate Affiliate Commissions from Totals Including Tax
by default commission calculated from amounts before tax' => 'Calculate Affiliate Commissions from Totals Including Tax
by default commission calculated from amounts before tax',
  'Can not find user with such username' => 'Can not find user with such username',
  'Can not find user with such username or email' => 'Can not find user with such username or email',
  'Can not save config for dashboard widget without config form [%s]' => 'Can not save config for dashboard widget without config form [%s]',
  'Can\'t be changed because your server have suhosin extension enabled' => 'Can\'t be changed because your server have suhosin extension enabled',
  'Cancel All Changes in Translations on Current Page' => 'Cancel All Changes in Translations on Current Page',
  'Cancellations' => 'Cancellations',
  'Cart View (Width x Height)' => 'Cart View (Width x Height)',
  'Category
root category of hierarchy which included to shopping cart
all categories is included by default' => 'Category
root category of hierarchy which included to shopping cart
all categories is included by default',
  'Change Configuration Settings' => 'Change Configuration Settings',
  'Change Invoice Rebill Date' => 'Change Invoice Rebill Date',
  'Change Password Notification
send email to user after password change' => 'Change Password Notification
send email to user after password change',
  'Change Paysystem' => 'Change Paysystem',
  'Change rebill date' => 'Change rebill date',
  'Charge Second Price Once' => 'Charge Second Price Once',
  'Charge Second Price x Times' => 'Charge Second Price x Times',
  'Check for beta version' => 'Check for beta version',
  'Check other Affiliate Program Settings' => 'Check other Affiliate Program Settings',
  'CheckBoxes' => 'CheckBoxes',
  'Choose %1$sFile%2$s > %1$sSave As%2$s.' => 'Choose %1$sFile%2$s > %1$sSave As%2$s.',
  'Choose Products and/or Product Categories that allows access' => 'Choose Products and/or Product Categories that allows access',
  'Choose Upgrades to Install' => 'Choose Upgrades to Install',
  'Choose a plugin' => 'Choose a plugin',
  'Choose action when locked %s used by customer during signup' => 'Choose action when locked %s used by customer during signup',
  'Choose another Report' => 'Choose another Report',
  'Clean up data. Please wait...' => 'Clean up data. Please wait...',
  'Clean up v4 Database' => 'Clean up v4 Database',
  'Clean up...' => 'Clean up...',
  'Cleaning up' => 'Cleaning up',
  'Cleanup' => 'Cleanup',
  'Clear' => 'Clear',
  'Clear Access Log' => 'Clear Access Log',
  'Clear Incomplete Invoices' => 'Clear Incomplete Invoices',
  'Click Tracking Code' => 'Click Tracking Code',
  'Click to Expand' => 'Click to Expand',
  'Code Length
generated coupon code length
between 5 and 32' => 'Code Length
generated coupon code length
between 5 and 32',
  'Collapse Menu' => 'Collapse Menu',
  'Comma' => 'Comma',
  'Comment
for your reference' => 'Comment
for your reference',
  'Comment for Your Reference' => 'Comment for Your Reference',
  'Commission
% of commission received by referred affiliate' => 'Commission
% of commission received by referred affiliate',
  'Commission for First Payment
calculated for first payment in each invoice' => 'Commission for First Payment
calculated for first payment in each invoice',
  'Commission for Free Signup
calculated for first customer invoice only' => 'Commission for Free Signup
calculated for first customer invoice only',
  'Commission for Rebills' => 'Commission for Rebills',
  'Commissions Included to Payout' => 'Commissions Included to Payout',
  'Company Logo for Invoice
it must be png/jpeg/tiff file (%s)' => 'Company Logo for Invoice
it must be png/jpeg/tiff file (%s)',
  'Config values updated...' => 'Config values updated...',
  'Configuration' => 'Configuration',
  'Configured License Keys' => 'Configured License Keys',
  'Copy' => 'Copy',
  'Copy Upgrades' => 'Copy Upgrades',
  'Copy from another language' => 'Copy from another language',
  'Core' => 'Core',
  'Could not download file [%s]. Error %s. Please %stry again%s later.' => 'Could not download file [%s]. Error %s. Please %stry again%s later.',
  'Could not fetch upgrades list from remote server. %sTry again%' => 'Could not fetch upgrades list from remote server. %sTry again%',
  'Could not fetch upgrades list. Connection error [%s]' => 'Could not fetch upgrades list. Connection error [%s]',
  'Could not move uploaded file' => 'Could not move uploaded file',
  'Could not open folder [%s] to remove .htaccess from it. Do it manually' => 'Could not open folder [%s] to remove .htaccess from it. Do it manually',
  'Could not read XML' => 'Could not read XML',
  'Could not write file [%s] - check file permissions and make sure it is writeable' => 'Could not write file [%s] - check file permissions and make sure it is writeable',
  'Count all IP as different' => 'Count all IP as different',
  'Count of Licenses' => 'Count of Licenses',
  'Countries/States' => 'Countries/States',
  'Country Title' => 'Country Title',
  'Coupon Batch' => 'Coupon Batch',
  'Coupon Code' => 'Coupon Code',
  'Coupon Codes' => 'Coupon Codes',
  'Coupon used for %d transactions' => 'Coupon used for %d transactions',
  'Coupons' => 'Coupons',
  'Coupons Batches' => 'Coupons Batches',
  'Coupons Count
how many coupons need to be generated' => 'Coupons Count
how many coupons need to be generated',
  'Coupons Usage Count
how many times coupon can be used' => 'Coupons Usage Count
how many times coupon can be used',
  'Create Folder' => 'Create Folder',
  'Create Session Key' => 'Create Session Key',
  'Create ticket as' => 'Create ticket as',
  'Credit' => 'Credit',
  'Credit Card Expiration Notice
if saved customer credit card expires soon, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only' => 'Credit Card Expiration Notice
if saved customer credit card expires soon, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only',
  'Credit Card Plugins' => 'Credit Card Plugins',
  'Credit Card Rebill Failed
if credit card rebill failed, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only' => 'Credit Card Rebill Failed
if credit card rebill failed, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only',
  'Credit Card Rebill Successfull
if credit card rebill was sucessfull, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only' => 'Credit Card Rebill Successfull
if credit card rebill was sucessfull, user will receive the following e-mail message. It works for payment processors like Authorize.Net and PayFlow Pro only',
  'Credit Type' => 'Credit Type',
  'Cron Last Run' => 'Cron Last Run',
  'Cron job has been running last time %s, it is more than 24 hours before.
Most possible external cron job has been set incorrectly. It may cause very serious problems with the script.
You can find info how to set up cron job for your installation <a class="link" href="http://www.amember.com/docs/Cron" target="_blank">here</a>.' => 'Cron job has been running last time %s, it is more than 24 hours before.
Most possible external cron job has been set incorrectly. It may cause very serious problems with the script.
You can find info how to set up cron job for your installation <a class="link" href="http://www.amember.com/docs/Cron" target="_blank">here</a>.',
  'Currency' => 'Currency',
  'Currency Exchange Rates' => 'Currency Exchange Rates',
  'Current Server Date and Time' => 'Current Server Date and Time',
  'Currently you see result of the following search' => 'Currently you see result of the following search',
  'Custom Bold Font for Invoice (optional)' => 'Custom Bold Font for Invoice (optional)',
  'Custom Commission Rules added' => 'Custom Commission Rules added',
  'Custom Font for Invoice (optional)' => 'Custom Font for Invoice (optional)',
  'Custom HTML' => 'Custom HTML',
  'Custom PDF Template for Invoice (optional)' => 'Custom PDF Template for Invoice (optional)',
  'Custom Signup Form Title
keep empty to use default title' => 'Custom Signup Form Title
keep empty to use default title',
  'Custom Template Settings' => 'Custom Template Settings',
  'Customer' => 'Customer',
  'Customize Dashboard' => 'Customize Dashboard',
  'Daily' => 'Daily',
  'Dashboard' => 'Dashboard',
  'Date Of Transaction' => 'Date Of Transaction',
  'Date Time' => 'Date Time',
  'Date to Purge
all records prior to this date will be removed from selected tables' => 'Date to Purge
all records prior to this date will be removed from selected tables',
  'Dates
date range when coupon can be used' => 'Dates
date range when coupon can be used',
  'Dates can be in the folowing formats' => 'Dates can be in the folowing formats',
  'Days to Send' => 'Days to Send',
  'Debit' => 'Debit',
  'Default - user clicks a link to become affiliate' => 'Default - user clicks a link to become affiliate',
  'Default Billing Plan' => 'Default Billing Plan',
  'Default Commission' => 'Default Commission',
  'Default Index Page' => 'Default Index Page',
  'Default Locale' => 'Default Locale',
  'Default Not Found Page' => 'Default Not Found Page',
  'Default Signup' => 'Default Signup',
  'Default Size
width&times;height' => 'Default Size
width&times;height',
  'Default for Members' => 'Default for Members',
  'Default value for field
(that is default value for inputs, not SQL DEFAULT)' => 'Default value for field
(that is default value for inputs, not SQL DEFAULT)',
  'Delay Payout (days)' => 'Delay Payout (days)',
  'Delete Old Records' => 'Delete Old Records',
  'Delete Preset' => 'Delete Preset',
  'Delete Saved Search?' => 'Delete Saved Search?',
  'Delete payment and access record' => 'Delete payment and access record',
  'Delimiter' => 'Delimiter',
  'Demo History' => 'Demo History',
  'Description
displayed to visitors on order page below the title' => 'Description
displayed to visitors on order page below the title',
  'Detail View (Width x Height)' => 'Detail View (Width x Height)',
  'Detailed Rebill Report for %s' => 'Detailed Rebill Report for %s',
  'Details' => 'Details',
  'Die and show ugly error message' => 'Die and show ugly error message',
  'Digits and latin letters only please' => 'Digits and latin letters only please',
  'Disable Checking for aMember Updates' => 'Disable Checking for aMember Updates',
  'Disable Customer Account' => 'Disable Customer Account',
  'Disable QuickStart Wizard' => 'Disable QuickStart Wizard',
  'Disable Visual HTML Editor' => 'Disable Visual HTML Editor',
  'Disable auto-locking for this customer' => 'Disable auto-locking for this customer',
  'Disabled' => 'Disabled',
  'Disallow for some affiliates, allow for others' => 'Disallow for some affiliates, allow for others',
  'Disallow new Signups by %s' => 'Disallow new Signups by %s',
  'Disallow ordering of this product if user has
when user orders this subscription, it will be checked
that he has no any from the following subscriptions' => 'Disallow ordering of this product if user has
when user orders this subscription, it will be checked
that he has no any from the following subscriptions',
  'Disallow use of coupon from this batch if user has
when user uses coupon, it will be checked
that he has no any from the following subscriptions' => 'Disallow use of coupon from this batch if user has
when user uses coupon, it will be checked
that he has no any from the following subscriptions',
  'Disclaimer of Credit Card Recurring Billing' => 'Disclaimer of Credit Card Recurring Billing',
  'Display' => 'Display',
  'Display Language Choice' => 'Display Language Choice',
  'Display Mode' => 'Display Mode',
  'Display error message' => 'Display error message',
  'Display inside layout
When displaying to customer, will the
header/footer from current theme be displayed?' => 'Display inside layout
When displaying to customer, will the
header/footer from current theme be displayed?',
  'Do not Allow Spaces in Username' => 'Do not Allow Spaces in Username',
  'Do not Include Subscription Terms to PDF Invoice' => 'Do not Include Subscription Terms to PDF Invoice',
  'Do not Lowercase Username
by default, aMember automatically lowercases entered username
here you can disable this function' => 'Do not Lowercase Username
by default, aMember automatically lowercases entered username
here you can disable this function',
  'Do not Show Unsubscribe Block on Member Page' => 'Do not Show Unsubscribe Block on Member Page',
  'Do not generate products
use existing products for demo records' => 'Do not generate products
use existing products for demo records',
  'Do not include Unsubscribe Link into e-mails' => 'Do not include Unsubscribe Link into e-mails',
  'Do you really want to change Rebill Date for this invoice?' => 'Do you really want to change Rebill Date for this invoice?',
  'Do you really want to delete this item?' => 'Do you really want to delete this item?',
  'Do you really want to refund payment' => 'Do you really want to refund payment',
  'Do you really want to restart this subscription?' => 'Do you really want to restart this subscription?',
  'Do you really want to stop this subscription?' => 'Do you really want to stop this subscription?',
  'Do you really want to void this commission?' => 'Do you really want to void this commission?',
  'Documentation' => 'Documentation',
  'Does Not Allow to Upload Attachments for Users' => 'Does Not Allow to Upload Attachments for Users',
  'Does Not Quote Message in Reply' => 'Does Not Quote Message in Reply',
  'Does Not Require Login to Access FAQ Section' => 'Does Not Require Login to Access FAQ Section',
  'Does Not Show FAQ Tab in Member Area' => 'Does Not Show FAQ Tab in Member Area',
  'Download Backup / Restore from Backup' => 'Download Backup / Restore from Backup',
  'Download CSV File' => 'Download CSV File',
  'Download Upgrades' => 'Download Upgrades',
  'Due Date' => 'Due Date',
  'Duration:' => 'Duration:',
  'E-Mail Address to Send to' => 'E-Mail Address to Send to',
  'E-Mail Backup Address' => 'E-Mail Backup Address',
  'E-Mail Commission to Admin' => 'E-Mail Commission to Admin',
  'E-Mail Commission to Affiliate' => 'E-Mail Commission to Affiliate',
  'E-Mail Database Backup' => 'E-Mail Database Backup',
  'E-Mail Messages on Rebilling Event' => 'E-Mail Messages on Rebilling Event',
  'E-Mail Payment Receipt to User
every time payment is received' => 'E-Mail Payment Receipt to User
every time payment is received',
  'E-Mail Queue' => 'E-Mail Queue',
  'E-Mail Sender Name
used to display name of sender in outgoing e-mails' => 'E-Mail Sender Name
used to display name of sender in outgoing e-mails',
  'E-Mail Sending' => 'E-Mail Sending',
  'E-Mail System Configuration' => 'E-Mail System Configuration',
  'E-Mail Type' => 'E-Mail Type',
  'E-Mail Users' => 'E-Mail Users',
  'E-Mail has been successfully sent to %s customers. E-Mail Batch ID is %s' => 'E-Mail has been successfully sent to %s customers. E-Mail Batch ID is %s',
  'E-Mail sending started' => 'E-Mail sending started',
  'E-Mails History' => 'E-Mails History',
  'E-Mails by Admin Request' => 'E-Mails by Admin Request',
  'E-Mails by User Request' => 'E-Mails by User Request',
  'EU VAT' => 'EU VAT',
  'EXPIRED subscription for %s' => 'EXPIRED subscription for %s',
  'EXPIRED subscription for group %s' => 'EXPIRED subscription for group %s',
  'Earn points for %s in payment' => 'Earn points for %s in payment',
  'Echeck Plugins' => 'Echeck Plugins',
  'Edit Custom Commission Rules' => 'Edit Custom Commission Rules',
  'Edit Groups' => 'Edit Groups',
  'Edit Messages' => 'Edit Messages',
  'Edit States' => 'Edit States',
  'Email' => 'Email',
  'Email Addresses Separated by Comma' => 'Email Addresses Separated by Comma',
  'Email Admin Regarding Account Sharing' => 'Email Admin Regarding Account Sharing',
  'Email Backup Frequency' => 'Email Backup Frequency',
  'Email Domain' => 'Email Domain',
  'Email Sending method
PLEASE DO NOT CHANGE if emailing from aMember works' => 'Email Sending method
PLEASE DO NOT CHANGE if emailing from aMember works',
  'Email Sent' => 'Email Sent',
  'Email Subject' => 'Email Subject',
  'Email Template with Payment Link' => 'Email Template with Payment Link',
  'Email User Regarding Account Sharing' => 'Email User Regarding Account Sharing',
  'Email address is required field.' => 'Email address is required field.',
  'Email has been send' => 'Email has been send',
  'Email is required if you have enabled Email Backup Feature' => 'Email is required if you have enabled Email Backup Feature',
  'Emails' => 'Emails',
  'Empty - 200x200 px' => 'Empty - 200x200 px',
  'Empty - 400x400 px' => 'Empty - 400x400 px',
  'Empty - 50x50 px' => 'Empty - 50x50 px',
  'Empty Payout Method Notification to User' => 'Empty Payout Method Notification to User',
  'Enable Click Tracking Code' => 'Enable Click Tracking Code',
  'Enable PDF Invoice
attach invoice file (.pdf) to Payment Receipt email' => 'Enable PDF Invoice
attach invoice file (.pdf) to Payment Receipt email',
  'Enable ability to track affiliate clicks on any page on your site' => 'Enable ability to track affiliate clicks on any page on your site',
  'Enable and configure external cron (%saMember CP -> Setup -> Advanced%s</a>) if you are using E-Mail Throttle Queue' => 'Enable and configure external cron (%saMember CP -> Setup -> Advanced%s</a>) if you are using E-Mail Throttle Queue',
  'Enable and configure external cron (%saMember CP -> Setup -> Advanced%s</a>) if you are using Periodic E-Mails (Autoresponder/Expiration/Pending Notifications)' => 'Enable and configure external cron (%saMember CP -> Setup -> Advanced%s</a>) if you are using Periodic E-Mails (Autoresponder/Expiration/Pending Notifications)',
  'Enable plugins if necessary' => 'Enable plugins if necessary',
  'Encrypted Pass' => 'Encrypted Pass',
  'Encrypted Password' => 'Encrypted Password',
  'End Date' => 'End Date',
  'Enter Maintenance Mode' => 'Enter Maintenance Mode',
  'Enter admin password for confirmation' => 'Enter admin password for confirmation',
  'Enter title for your new category' => 'Enter title for your new category',
  'Error Log' => 'Error Log',
  'Error deleting record! Please refresh page and try again' => 'Error deleting record! Please refresh page and try again',
  'Error during e-mail sending' => 'Error during e-mail sending',
  'Error occurred, please check Errors Log for clue' => 'Error occurred, please check Errors Log for clue',
  'Error/Debug Log' => 'Error/Debug Log',
  'Errors' => 'Errors',
  'Errors:' => 'Errors:',
  'European (A4)' => 'European (A4)',
  'European Date Format' => 'European Date Format',
  'Every %s' => 'Every %s',
  'Exchange Rate' => 'Exchange Rate',
  'Exchange Rate
enter cost of 1 (one) %s' => 'Exchange Rate
enter cost of 1 (one) %s',
  'Expiration message will be sent when configured conditions met.
Additional restrictions applies to do not sent unnecessary e-mails.
Expiration message will not be sent if:
<ul>
    <li>User has other active products with the same renewal group</li>
    <li>User has unsubscribed from e-mail messages</li>
</ul>' => 'Expiration message will be sent when configured conditions met.
Additional restrictions applies to do not sent unnecessary e-mails.
Expiration message will not be sent if:
<ul>
    <li>User has other active products with the same renewal group</li>
    <li>User has unsubscribed from e-mail messages</li>
</ul>',
  'Expire (maximum expiration date)' => 'Expire (maximum expiration date)',
  'Field' => 'Field',
  'Field Description' => 'Field Description',
  'Field Name' => 'Field Name',
  'Field Title' => 'Field Title',
  'Field Type' => 'Field Type',
  'Field Values' => 'Field Values',
  'File
(max filesize %s)' => 'File
(max filesize %s)',
  'File %s is already exist. You can not create already existing translation.' => 'File %s is already exist. You can not create already existing translation.',
  'File [%s] cannot be deleted - remove it manually to unprotect folder' => 'File [%s] cannot be deleted - remove it manually to unprotect folder',
  'File [%s] contains not only aMember code - remove it manually to unprotect folder' => 'File [%s] contains not only aMember code - remove it manually to unprotect folder',
  'File is required' => 'File is required',
  'Filename for Invoice
%public_id% will be replaced with real public id of invoice, %receipt_id% will be replaced with payment receipt, also you can use the following placehoders %payment.date%, %user.name_f%, %user.name_l%' => 'Filename for Invoice
%public_id% will be replaced with real public id of invoice, %receipt_id% will be replaced with payment receipt, also you can use the following placehoders %payment.date%, %user.name_f%, %user.name_l%',
  'Filter By Coupon#' => 'Filter By Coupon#',
  'Filter By Title or Category' => 'Filter By Title or Category',
  'Filter By Username/Name/E-Mail/Invoice#/Receipt#/Remote Addr' => 'Filter By Username/Name/E-Mail/Invoice#/Receipt#/Remote Addr',
  'Filter by Affiliate/Banner/IP' => 'Filter by Affiliate/Banner/IP',
  'Filter by Affiliate/User/Banner' => 'Filter by Affiliate/User/Banner',
  'Filter by Affiliate/User/Product' => 'Filter by Affiliate/User/Product',
  'Filter by Category' => 'Filter by Category',
  'Filter by Code' => 'Filter by Code',
  'Filter by Counrty Title' => 'Filter by Counrty Title',
  'Filter by IP or Referrer or URL' => 'Filter by IP or Referrer or URL',
  'Filter by Paysystem' => 'Filter by Paysystem',
  'Filter by Plugin' => 'Filter by Plugin',
  'Filter by Product' => 'Filter by Product',
  'Filter by State Title' => 'Filter by State Title',
  'Filter by Subject' => 'Filter by Subject',
  'Filter by User/Product' => 'Filter by User/Product',
  'Filter by name or description' => 'Filter by name or description',
  'Filter by record_id or by message' => 'Filter by record_id or by message',
  'Filter by string or by invoice#/member#' => 'Filter by string or by invoice#/member#',
  'Filter by subject or recepient' => 'Filter by subject or recepient',
  'Filtered' => 'Filtered',
  'First Payment (calculated for first payment in each invoice)' => 'First Payment (calculated for first payment in each invoice)',
  'First Period' => 'First Period',
  'First Price' => 'First Price',
  'First Price
price of first period of subscription' => 'First Price
price of first period of subscription',
  'First Tax' => 'First Tax',
  'First Total' => 'First Total',
  'First and Last Name' => 'First and Last Name',
  'First available protected url' => 'First available protected url',
  'First visited' => 'First visited',
  'Fix aMember Pro License Key' => 'Fix aMember Pro License Key',
  'Fixed Url' => 'Fixed Url',
  'Fixed date' => 'Fixed date',
  'FlowPlayer License Key
you may get your key in %smembers area%s' => 'FlowPlayer License Key
you may get your key in %smembers area%s',
  'Folder %s is not a writable for the PHP script. Please <br />
            chmod this file using webhosting control panel file manager or using your<br />
            favorite FTP client to 777 (write and read for all)<br />
            Please, don\'t forget to chmod it back to 755 after creation of translation' => 'Folder %s is not a writable for the PHP script. Please <br />
            chmod this file using webhosting control panel file manager or using your<br />
            favorite FTP client to 777 (write and read for all)<br />
            Please, don\'t forget to chmod it back to 755 after creation of translation',
  'Folder URL' => 'Folder URL',
  'Form Type' => 'Form Type',
  'Forms Editor' => 'Forms Editor',
  'From' => 'From',
  'Future' => 'Future',
  'General' => 'General',
  'General Affiliate Link Redirect URL' => 'General Affiliate Link Redirect URL',
  'General Link' => 'General Link',
  'General Settings' => 'General Settings',
  'Generate' => 'Generate',
  'Generate Basket HTML' => 'Generate Basket HTML',
  'Generate Button HTML' => 'Generate Button HTML',
  'Generate Payout Manually' => 'Generate Payout Manually',
  'Generate Products Count' => 'Generate Products Count',
  'Generate Random Coupon Codes (You will be able to alter codes later if you want)' => 'Generate Random Coupon Codes (You will be able to alter codes later if you want)',
  'Generate Report' => 'Generate Report',
  'Generate Users Count' => 'Generate Users Count',
  'Generated' => 'Generated',
  'Generated License Valid To' => 'Generated License Valid To',
  'Generation of demo data  was terminated while processing. Not all records were created.' => 'Generation of demo data  was terminated while processing. Not all records were created.',
  'Get Available Upgrades List' => 'Get Available Upgrades List',
  'Get New Password' => 'Get New Password',
  'Global' => 'Global',
  'Global Translations' => 'Global Translations',
  'Graph Bar' => 'Graph Bar',
  'Graph Line' => 'Graph Line',
  'Gravatar' => 'Gravatar',
  'HTML Code' => 'HTML Code',
  'HTML E-Mail Unsubscribe Link
%link% will be replaced to actual unsubscribe URL' => 'HTML E-Mail Unsubscribe Link
%link% will be replaced to actual unsubscribe URL',
  'Hash' => 'Hash',
  'Height' => 'Height',
  'Help & Support' => 'Help & Support',
  'Hide' => 'Hide',
  'Hide \'Add/Renew Subscription\' tab (User Menu)
and show \'Shopping Cart\' tab instead' => 'Hide \'Add/Renew Subscription\' tab (User Menu)
and show \'Shopping Cart\' tab instead',
  'Hide Authentication Widget' => 'Hide Authentication Widget',
  'Hide Choose Category Widget' => 'Hide Choose Category Widget',
  'Hide Product Search Widget' => 'Hide Product Search Widget',
  'Hide Your Basket Widget' => 'Hide Your Basket Widget',
  'Home Page' => 'Home Page',
  'Hostname' => 'Hostname',
  'Hour' => 'Hour',
  'I understand that upgrade may overwrite customized PHP files and templates, I have already made a backup of aMember Pro folder and database' => 'I understand that upgrade may overwrite customized PHP files and templates, I have already made a backup of aMember Pro folder and database',
  'IMPORTANT NOTE:' => 'IMPORTANT NOTE:',
  'IMPORTANT NOTE: This will not protect content. If someone know link url, he will be able to open link without a problem. This just control what additional links user will see after login to member\'s area.' => 'IMPORTANT NOTE: This will not protect content. If someone know link url, he will be able to open link without a problem. This just control what additional links user will see after login to member\'s area.',
  'IP' => 'IP',
  'IP within' => 'IP within',
  'If only one protected URL, go directly to the URL. Otherwise go to membership page' => 'If only one protected URL, go directly to the URL. Otherwise go to membership page',
  'If you are moving from one payment processor, you can use this page to switch existing subscription from one payment processor to another. It is possible only if full credit card info is stored on aMember side.' => 'If you are moving from one payment processor, you can use this page to switch existing subscription from one payment processor to another. It is possible only if full credit card info is stored on aMember side.',
  'Image' => 'Image',
  'Image height must be number greater than 0.' => 'Image height must be number greater than 0.',
  'Image width must be number greater than 0.' => 'Image width must be number greater than 0.',
  'Immediately' => 'Immediately',
  'Import E-Mail Templates from XML file' => 'Import E-Mail Templates from XML file',
  'Import Encrypted Password' => 'Import Encrypted Password',
  'Import Finished' => 'Import Finished',
  'Import Finished. %d templates imported.' => 'Import Finished. %d templates imported.',
  'Import History' => 'Import History',
  'Import Pre-Defined List of Coupon Codes from CSV File (One coupon code per line)' => 'Import Pre-Defined List of Coupon Codes from CSV File (One coupon code per line)',
  'Import Users' => 'Import Users',
  'Import data. Please wait...' => 'Import data. Please wait...',
  'Import of data was terminated while processing. Anyway some data was imported.' => 'Import of data was terminated while processing. Anyway some data was imported.',
  'Import...' => 'Import...',
  'Import: step 3 of 4' => 'Import: step 3 of 4',
  'Import: step 4 of 4' => 'Import: step 4 of 4',
  'Important Notice:' => 'Important Notice:',
  'In case of video do not start play before
full download and you use <a class="link" href="http://en.wikipedia.org/wiki/MPEG-4_Part_14">mp4 format</a>
more possible that metadata (moov atom) is located
at the end of file. There is special programs that allow to relocate
this metadata to the beginning of your file and allow play video before full
download (On Linux mashine you can use <em>qt-faststart</em> utility to do it).
Also your video editor can has option to locate metadata at beginning of file
(something like <em>FastStart</em> or <em>Web Optimized</em> option).
You need to relocate metadata for this file and reupload
it to aMember. You can use such utilites as <em>AtomicParsley</em> or similar
to check your file structure.' => 'In case of video do not start play before
full download and you use <a class="link" href="http://en.wikipedia.org/wiki/MPEG-4_Part_14">mp4 format</a>
more possible that metadata (moov atom) is located
at the end of file. There is special programs that allow to relocate
this metadata to the beginning of your file and allow play video before full
download (On Linux mashine you can use <em>qt-faststart</em> utility to do it).
Also your video editor can has option to locate metadata at beginning of file
(something like <em>FastStart</em> or <em>Web Optimized</em> option).
You need to relocate metadata for this file and reupload
it to aMember. You can use such utilites as <em>AtomicParsley</em> or similar
to check your file structure.',
  'In the Export of text files dialog, select the options you want and then click %1$sOK%2$s.' => 'In the Export of text files dialog, select the options you want and then click %1$sOK%2$s.',
  'In the File name box, type a name for the file.' => 'In the File name box, type a name for the file.',
  'In the File type list, select %1$sText CSV%2$s and click %1$sSave%2$s. You may see the message box. Click %1$sKeep Current Format%2$s.' => 'In the File type list, select %1$sText CSV%2$s and click %1$sSave%2$s. You may see the message box. Click %1$sKeep Current Format%2$s.',
  'Include Access Periods to PDF Invoice' => 'Include Access Periods to PDF Invoice',
  'Index Page' => 'Index Page',
  'Insert' => 'Insert',
  'Install Updates' => 'Install Updates',
  'Instances Limit
How many simultaneous bindings for license may exists (default - 1)' => 'Instances Limit
How many simultaneous bindings for license may exists (default - 1)',
  'Integer Value' => 'Integer Value',
  'Integer field (only numbers)' => 'Integer field (only numbers)',
  'Integration plugins' => 'Integration plugins',
  'Internal PHP mail() function (default)' => 'Internal PHP mail() function (default)',
  'Intro Text on Affiliate Info Page' => 'Intro Text on Affiliate Info Page',
  'Intro Text on Helpdesk Page' => 'Intro Text on Helpdesk Page',
  'Invoice (Internal Id)' => 'Invoice (Internal Id)',
  'Invoice (Public Id)' => 'Invoice (Public Id)',
  'Invoice Approved Notification to User (Invoice)' => 'Invoice Approved Notification to User (Invoice)',
  'Invoice Contact information
included at top, use &lt;br&gt; for new line' => 'Invoice Contact information
included at top, use &lt;br&gt; for new line',
  'Invoice Footer Note
This text will be included at bottom to PDF Invoice. You can use all user specific placeholders here eg. %user.login%, %user.name_f%, %user.name_l% etc.' => 'Invoice Footer Note
This text will be included at bottom to PDF Invoice. You can use all user specific placeholders here eg. %user.login%, %user.name_f%, %user.name_l% etc.',
  'Invoice Log' => 'Invoice Log',
  'Invoice Number' => 'Invoice Number',
  'Invoice link has been sent to user again' => 'Invoice link has been sent to user again',
  'Invoices' => 'Invoices',
  'Invoices Information' => 'Invoices Information',
  'Invoices Per User' => 'Invoices Per User',
  'Is Approved' => 'Is Approved',
  'Is Disabled' => 'Is Disabled',
  'Is Disabled?
If you disable this coupons batch, it will
not be available for new purchases.
Existing invoices are not affected.
' => 'Is Disabled?
If you disable this coupons batch, it will
not be available for new purchases.
Existing invoices are not affected.
',
  'Is Disabled?
disable product ordering, hide it from signup and renewal forms' => 'Is Disabled?
disable product ordering, hide it from signup and renewal forms',
  'Is Paid?' => 'Is Paid?',
  'Is Unsubscribed?
if enabled, this will
unsubscribe the customer from:
* messages that you send from aMember Cp,
* autoresponder messages,
* subscription expiration notices' => 'Is Unsubscribed?
if enabled, this will
unsubscribe the customer from:
* messages that you send from aMember Cp,
* autoresponder messages,
* subscription expiration notices',
  'It is required to setup a cron job to trigger backup generation' => 'It is required to setup a cron job to trigger backup generation',
  'It is url of landing page for default affiliate link (which does not related to any banner), home page will be used if you keep it empty' => 'It is url of landing page for default affiliate link (which does not related to any banner), home page will be used if you keep it empty',
  'It will replace all your exising database with backup. Do you really want to proceed?' => 'It will replace all your exising database with backup. Do you really want to proceed?',
  'Items' => 'Items',
  'JWPlayer License Key' => 'JWPlayer License Key',
  'JavaScript Code' => 'JavaScript Code',
  'Just Add Pending Invoice' => 'Just Add Pending Invoice',
  'Key' => 'Key',
  'Key Generator' => 'Key Generator',
  'Key must be 20 chars or longer' => 'Key must be 20 chars or longer',
  'Keygenerator' => 'Keygenerator',
  'Languages' => 'Languages',
  'Last %s Customers' => 'Last %s Customers',
  'Last %s Helpdesk Messages' => 'Last %s Helpdesk Messages',
  'Last %s Invoices' => 'Last %s Invoices',
  'Last %s Payments' => 'Last %s Payments',
  'Last %s Refunds' => 'Last %s Refunds',
  'Last %s User Signin' => 'Last %s User Signin',
  'Last Invoices List' => 'Last Invoices List',
  'Last Payments List' => 'Last Payments List',
  'Last Refunds List' => 'Last Refunds List',
  'Last Signin' => 'Last Signin',
  'Last Signin Info' => 'Last Signin Info',
  'Last User Logins List' => 'Last User Logins List',
  'Last Users List' => 'Last Users List',
  'Last available protected url' => 'Last available protected url',
  'Last existing subscription date of this product' => 'Last existing subscription date of this product',
  'Last expiration date in the renewal group' => 'Last expiration date in the renewal group',
  'Last login' => 'Last login',
  'Layout' => 'Layout',
  'Leads' => 'Leads',
  'Leave this checkbox unselected to restrict affiliates from seeing their sales details' => 'Leave this checkbox unselected to restrict affiliates from seeing their sales details',
  'Length of admin password must be from %d to %d' => 'Length of admin password must be from %d to %d',
  'Length of username must be from %d to %d' => 'Length of username must be from %d to %d',
  'Licensing Method' => 'Licensing Method',
  'Lifetime (%s)' => 'Lifetime (%s)',
  'Light Box' => 'Light Box',
  'Light Boxes' => 'Light Boxes',
  'Lightbox Main Image' => 'Lightbox Main Image',
  'Lightbox Thumbnail Image' => 'Lightbox Thumbnail Image',
  'Limit Downloads Count' => 'Limit Downloads Count',
  'Lines Proccessed:' => 'Lines Proccessed:',
  'Lines Skipped:' => 'Lines Skipped:',
  'Lines Success:' => 'Lines Success:',
  'Link to reset your password was sent to your Email.' => 'Link to reset your password was sent to your Email.',
  'List View (Width x Height)' => 'List View (Width x Height)',
  'Loading' => 'Loading',
  'Loading...' => 'Loading...',
  'Local Translations' => 'Local Translations',
  'Lock' => 'Lock',
  'Locked Value' => 'Locked Value',
  'Log In' => 'Log In',
  'Log Outgoing E-Mail Messages for ... days' => 'Log Outgoing E-Mail Messages for ... days',
  'Log in' => 'Log in',
  'Login As User' => 'Login As User',
  'Login Page' => 'Login Page',
  'Login as User' => 'Login as User',
  'Logs' => 'Logs',
  'Logs: Access' => 'Logs: Access',
  'Logs: Admin Log' => 'Logs: Admin Log',
  'Logs: Errors' => 'Logs: Errors',
  'Logs: Invoice' => 'Logs: Invoice',
  'Logs: Mail Queue' => 'Logs: Mail Queue',
  'Lookup' => 'Lookup',
  'Lost your password?' => 'Lost your password?',
  'Mail' => 'Mail',
  'Maintenance Mode' => 'Maintenance Mode',
  'Maintenance mode is currently enabled. Only logged-in administrators like you can access it. %sDisable%s' => 'Maintenance mode is currently enabled. Only logged-in administrators like you can access it. %sDisable%s',
  'Manage Additional User Fields' => 'Manage Additional User Fields',
  'Manage Countries/States' => 'Manage Countries/States',
  'Manage Product Upgrade Paths' => 'Manage Product Upgrade Paths',
  'Manage Products' => 'Manage Products',
  'Manage Translation of Messages' => 'Manage Translation of Messages',
  'Manually Added' => 'Manually Added',
  'Manually Approve' => 'Manually Approve',
  'Manually Approve New Invoices' => 'Manually Approve New Invoices',
  'Manually Approve New Users' => 'Manually Approve New Users',
  'Manually Approve Note (New Signup/Invoice)' => 'Manually Approve Note (New Signup/Invoice)',
  'Mark NOT Paid' => 'Mark NOT Paid',
  'Mark Paid' => 'Mark Paid',
  'Mass Subscribe' => 'Mass Subscribe',
  'Membership' => 'Membership',
  'Membership Info Page' => 'Membership Info Page',
  'Merge' => 'Merge',
  'Message
will be included to email to user' => 'Message
will be included to email to user',
  'Message Text' => 'Message Text',
  'Messages to Customer after Payment' => 'Messages to Customer after Payment',
  'Method' => 'Method',
  'Minimum Payout' => 'Minimum Payout',
  'Miscellaneous' => 'Miscellaneous',
  'Modules' => 'Modules',
  'Monthly' => 'Monthly',
  'Msg' => 'Msg',
  'Multiple Order Title
when user ordering multiple products,
display the following on payment system
instead of product name' => 'Multiple Order Title
when user ordering multiple products,
display the following on payment system
instead of product name',
  'Multiply commission calculated by the following rules
to number specified in this field. To keep commission untouched, enter 1 or delete this rule' => 'Multiply commission calculated by the following rules
to number specified in this field. To keep commission untouched, enter 1 or delete this rule',
  'NEVER (oops! no records that it has been running at all!)' => 'NEVER (oops! no records that it has been running at all!)',
  'Name F' => 'Name F',
  'Name L' => 'Name L',
  'Name must be entered and it may contain lowercase letters, underscores and digits' => 'Name must be entered and it may contain lowercase letters, underscores and digits',
  'Name of Preset' => 'Name of Preset',
  'Name of template is undefined' => 'Name of template is undefined',
  'Nearest' => 'Nearest',
  'Nearest 15th Day of Month' => 'Nearest 15th Day of Month',
  'Nearest 1st Day of Month' => 'Nearest 1st Day of Month',
  'Nearest Friday' => 'Nearest Friday',
  'Nearest Monday' => 'Nearest Monday',
  'Nearest Saturday' => 'Nearest Saturday',
  'Nearest Sunday' => 'Nearest Sunday',
  'Nearest Thursday' => 'Nearest Thursday',
  'Nearest Tuesday' => 'Nearest Tuesday',
  'Nearest Wednesday' => 'Nearest Wednesday',
  'Need points to get %s discount' => 'Need points to get %s discount',
  'New Affiliate Payout to Admin' => 'New Affiliate Payout to Admin',
  'New Autoresponder' => 'New Autoresponder',
  'New Expiration E-Mail' => 'New Expiration E-Mail',
  'New Modules Available' => 'New Modules Available',
  'New Rewrite' => 'New Rewrite',
  'New Ticket Autoresponder to Customer
aMember will email an autoresponder to user
each time user create new ticket' => 'New Ticket Autoresponder to Customer
aMember will email an autoresponder to user
each time user create new ticket',
  'New password has been e-mailed to your e-mail address' => 'New password has been e-mailed to your e-mail address',
  'Next Day' => 'Next Day',
  'Next rebill date' => 'Next rebill date',
  'No Access URL
customer without required access will be redirected to this url
leave empty if you want to redirect to default \'No access\' page' => 'No Access URL
customer without required access will be redirected to this url
leave empty if you want to redirect to default \'No access\' page',
  'No Access URL
customer without required access will see link to this url in the player window
leave empty if you want to redirect to default \'No access\' page' => 'No Access URL
customer without required access will see link to this url in the player window
leave empty if you want to redirect to default \'No access\' page',
  'No Credit Cards stored for this customer. %sAdd Credit Card%s' => 'No Credit Cards stored for this customer. %sAdd Credit Card%s',
  'No Echecks stored for this customer. %sAdd Echeck%s' => 'No Echecks stored for this customer. %sAdd Echeck%s',
  'No Invoices Found' => 'No Invoices Found',
  'No License Configured' => 'No License Configured',
  'No Tax' => 'No Tax',
  'No Updates Available' => 'No Updates Available',
  'No activation' => 'No activation',
  'No more charges' => 'No more charges',
  'No one line found in the file. It looks like file is empty. You can go back and try another file.' => 'No one line found in the file. It looks like file is empty. You can go back and try another file.',
  'No protection plugins enabled, please enable new-rewrite or htpasswd at aMember CP -> Setup -> Plugins' => 'No protection plugins enabled, please enable new-rewrite or htpasswd at aMember CP -> Setup -> Plugins',
  'No search name passed' => 'No search name passed',
  'No upgrades to install' => 'No upgrades to install',
  'Not Approved' => 'Not Approved',
  'Not Approved Users' => 'Not Approved Users',
  'Not Confirmed Users' => 'Not Confirmed Users',
  'Not-SQL field (default)' => 'Not-SQL field (default)',
  'Number of Invoices to display' => 'Number of Invoices to display',
  'Number of License Reactivations Allowed
for all instances (default - 0)' => 'Number of License Reactivations Allowed
for all instances (default - 0)',
  'Number of Payments to display' => 'Number of Payments to display',
  'Number of Refunds to display' => 'Number of Refunds to display',
  'Number of Users to display' => 'Number of Users to display',
  'Number of invoices which require approval: %d. %sClick here%s to review these invoices.' => 'Number of invoices which require approval: %d. %sClick here%s to review these invoices.',
  'Number of users who require approval: %d. %sClick here%s to review these users.' => 'Number of users who require approval: %d. %sClick here%s to review these users.',
  'Numeric Value' => 'Numeric Value',
  'Numeric field' => 'Numeric field',
  'OK' => 'OK',
  'OTO - Offer to purchase additional product (with optional discount)' => 'OTO - Offer to purchase additional product (with optional discount)',
  'One Column' => 'One Column',
  'One field can be assigned to one column only, you assigned following fields to several columns: ' => 'One field can be assigned to one column only, you assigned following fields to several columns: ',
  'One field can be assigned to one column only.' => 'One field can be assigned to one column only.',
  'Only admin can enable user as an affiliate' => 'Only admin can enable user as an affiliate',
  'Optional Conditions (By Paysystem)' => 'Optional Conditions (By Paysystem)',
  'Optional Conditions (By Product)' => 'Optional Conditions (By Product)',
  'Outgoing Email Address
used as From: address for sending e-mail messages
to customers. If empty, [Admin E-Mail Address] is used' => 'Outgoing Email Address
used as From: address for sending e-mail messages
to customers. If empty, [Admin E-Mail Address] is used',
  'Overwrite User if Exist User with Same Login' => 'Overwrite User if Exist User with Same Login',
  'Owner' => 'Owner',
  'PDF Invoice' => 'PDF Invoice',
  'Page Not Found (404)' => 'Page Not Found (404)',
  'Page Peel' => 'Page Peel',
  'Page Where Logout Link was Clicked' => 'Page Where Logout Link was Clicked',
  'Paid' => 'Paid',
  'Paper Format' => 'Paper Format',
  'Password Length' => 'Password Length',
  'Password changed' => 'Password changed',
  'Password must not be equal to username' => 'Password must not be equal to username',
  'Passwords must be the same' => 'Passwords must be the same',
  'Path to Folder' => 'Path to Folder',
  'Path/URL' => 'Path/URL',
  'Payment Amount' => 'Payment Amount',
  'Payment Date' => 'Payment Date',
  'Payment Receipt' => 'Payment Receipt',
  'Payment date' => 'Payment date',
  'Payment has been successfully refunded' => 'Payment has been successfully refunded',
  'Payment#/Receipt#' => 'Payment#/Receipt#',
  'Payments (amount of all payments made by user minus refunds)' => 'Payments (amount of all payments made by user minus refunds)',
  'Payout' => 'Payout',
  'Payout %d Details' => 'Payout %d Details',
  'Payout Date' => 'Payout Date',
  'Payout Details' => 'Payout Details',
  'Payout Method' => 'Payout Method',
  'Paysystem' => 'Paysystem',
  'Pending Invoice Notification Rules' => 'Pending Invoice Notification Rules',
  'Pending Invoice Notifications to Admin
only one email will be send for each defined day.
all email for specific day will be selected and conditions will be checked.
First email with matched condition will be send and other ignored' => 'Pending Invoice Notifications to Admin
only one email will be send for each defined day.
all email for specific day will be selected and conditions will be checked.
First email with matched condition will be send and other ignored',
  'Pending Invoice Notifications to User
only one email will be send for each defined day.
all email for specific day will be selected and conditions will be checked.
First email with matched condition will be send and other ignored' => 'Pending Invoice Notifications to User
only one email will be send for each defined day.
all email for specific day will be selected and conditions will be checked.
First email with matched condition will be send and other ignored',
  'Permissions' => 'Permissions',
  'Player Configuration' => 'Player Configuration',
  'Please assign the following fields: ' => 'Please assign the following fields: ',
  'Please choose another field name. This name is already used' => 'Please choose another field name. This name is already used',
  'Please choose product' => 'Please choose product',
  'Please click on the button below to create backup of aMembers tables in MySQL database.' => 'Please click on the button below to create backup of aMembers tables in MySQL database.',
  'Please enter expire date' => 'Please enter expire date',
  'Please enter one or more email' => 'Please enter one or more email',
  'Please enter start date' => 'Please enter start date',
  'Please enter valid e-mail address' => 'Please enter valid e-mail address',
  'Please enter valid e-mail addresses' => 'Please enter valid e-mail addresses',
  'Please enter your username or email
address. You will receive a link to create
a new password via email.' => 'Please enter your username or email
address. You will receive a link to create
a new password via email.',
  'Please note: By default, aMember does not change users password and login values to a generated value in cases where an existing email address is found. You may decide to update an existing record, in the next step of the import process, where a matching email or username already exists.' => 'Please note: By default, aMember does not change users password and login values to a generated value in cases where an existing email address is found. You may decide to update an existing record, in the next step of the import process, where a matching email or username already exists.',
  'Please run %sRebuild Db%s to update status for imported customers' => 'Please run %sRebuild Db%s to update status for imported customers',
  'Please select date before today' => 'Please select date before today',
  'Please specify new rebill date: ' => 'Please specify new rebill date: ',
  'Please upload .ttf file only.' => 'Please upload .ttf file only.',
  'Please upload file [<i>%s</i>]<br />' => 'Please upload file [<i>%s</i>]<br />',
  'Please wait' => 'Please wait',
  'Plugins' => 'Plugins',
  'Poster Image
applicable only for video files' => 'Poster Image
applicable only for video files',
  'Product Availability' => 'Product Availability',
  'Product Category' => 'Product Category',
  'Product Category: ' => 'Product Category: ',
  'Product Image' => 'Product Image',
  'Product Title' => 'Product Title',
  'Product Upgrades' => 'Product Upgrades',
  'Product: ' => 'Product: ',
  'Products
coupons can be used with selected products only.
if nothing selected, coupon can be used with any product' => 'Products
coupons can be used with selected products only.
if nothing selected, coupon can be used with any product',
  'Products Per Invoice' => 'Products Per Invoice',
  'Products per Page' => 'Products per Page',
  'Products that bring credits' => 'Products that bring credits',
  'Products that can be purchased with credits' => 'Products that can be purchased with credits',
  'Protect Content' => 'Protect Content',
  'Protect Files List' => 'Protect Files List',
  'Protection Method' => 'Protection Method',
  'Quantity
default - 1, normally you do not need to change it
First and Second Price is the total for specified qty' => 'Quantity
default - 1, normally you do not need to change it
First and Second Price is the total for specified qty',
  'Quit Maintenance Mode' => 'Quit Maintenance Mode',
  'REST API Documentation' => 'REST API Documentation',
  'RadioButtons' => 'RadioButtons',
  'Re Send Payment Link' => 'Re Send Payment Link',
  'ReCaptcha' => 'ReCaptcha',
  'ReCaptcha Theme' => 'ReCaptcha Theme',
  'ReCaptcha Theme for Login Page' => 'ReCaptcha Theme for Login Page',
  'Rebill' => 'Rebill',
  'Rebill Date' => 'Rebill Date',
  'Rebill Date changed from %s to %s' => 'Rebill Date changed from %s to %s',
  'Rebill Opereation Completed for %s' => 'Rebill Opereation Completed for %s',
  'Rebill Second Price until cancelled' => 'Rebill Second Price until cancelled',
  'Rebill Times
This is the number of payments which
will occur at the Second Price' => 'Rebill Times
This is the number of payments which
will occur at the Second Price',
  'Rebill date has been changed!' => 'Rebill date has been changed!',
  'Rebills' => 'Rebills',
  'Rebuild DB' => 'Rebuild DB',
  'Rebuild Db' => 'Rebuild Db',
  'Rebuild Users Database' => 'Rebuild Users Database',
  'Receipt' => 'Receipt',
  'Receipt#' => 'Receipt#',
  'Recipients' => 'Recipients',
  'Record Type' => 'Record Type',
  'Record modified, original dates:' => 'Record modified, original dates:',
  'Records Deleted Sucessfully' => 'Records Deleted Sucessfully',
  'Records per Page (for grids)' => 'Records per Page (for grids)',
  'Recurring' => 'Recurring',
  'Redirect' => 'Redirect',
  'Redirect After Login
where customer redirected after successful
login at %s' => 'Redirect After Login
where customer redirected after successful
login at %s',
  'Redirect After Logout' => 'Redirect After Logout',
  'Redirect to Signup Cart Page by Default' => 'Redirect to Signup Cart Page by Default',
  'Referer' => 'Referer',
  'Referrer' => 'Referrer',
  'Refund Amount' => 'Refund Amount',
  'Refund Date' => 'Refund Date',
  'Refund Payment' => 'Refund Payment',
  'Refund Type' => 'Refund Type',
  'Refunds' => 'Refunds',
  'Refunds are not implemented for this payment system. This action will not issue actual refund it will just add refund record in aMember and revoke user access. You must go to payment processor and do actual refund if you did not do it yet.' => 'Refunds are not implemented for this payment system. This action will not issue actual refund it will just add refund record in aMember and revoke user access. You must go to payment processor and do actual refund if you did not do it yet.',
  'Remember Login
remember username/password in cookies' => 'Remember Login
remember username/password in cookies',
  'Remember Period
cookie will be stored for ... days' => 'Remember Period
cookie will be stored for ... days',
  'Remind Password to Admin' => 'Remind Password to Admin',
  'Remind Password to Customer' => 'Remind Password to Customer',
  'Remove Category' => 'Remove Category',
  'Remove From Dashboard' => 'Remove From Dashboard',
  'Remove Group' => 'Remove Group',
  'Renewal Group' => 'Renewal Group',
  'Reparing' => 'Reparing',
  'Repeat Action Handling' => 'Repeat Action Handling',
  'Replace Product' => 'Replace Product',
  'Report Bugs' => 'Report Bugs',
  'Report Settings' => 'Report Settings',
  'Report Type' => 'Report Type',
  'Reports' => 'Reports',
  'Require Approval Notification to Admin (New Signup)' => 'Require Approval Notification to Admin (New Signup)',
  'Require Approval Notification to User  (New Signup)' => 'Require Approval Notification to User  (New Signup)',
  'Require Approval Only if Invoice has these Products (Invoice)' => 'Require Approval Only if Invoice has these Products (Invoice)',
  'Require Strong Password' => 'Require Strong Password',
  'Required value' => 'Required value',
  'Reseller Packages' => 'Reseller Packages',
  'Resend' => 'Resend',
  'Resend Email' => 'Resend Email',
  'Resend Payment Link' => 'Resend Payment Link',
  'Resend Signup E-Mail' => 'Resend Signup E-Mail',
  'Resource' => 'Resource',
  'Restart Recurring' => 'Restart Recurring',
  'Restart Subscription' => 'Restart Subscription',
  'Restart is not allowed' => 'Restart is not allowed',
  'Restore' => 'Restore',
  'Restore Database from Backup' => 'Restore Database from Backup',
  'Restore Password' => 'Restore Password',
  'Restored Successfully' => 'Restored Successfully',
  'Retreive Access Parameters if necessary' => 'Retreive Access Parameters if necessary',
  'Return to Payouts List' => 'Return to Payouts List',
  'Root' => 'Root',
  'Root Folder' => 'Root Folder',
  'Root URL
root script URL, usually %s' => 'Root URL
root script URL, usually %s',
  'Root Url and License Keys' => 'Root Url and License Keys',
  'Rule Removed' => 'Rule Removed',
  'Run' => 'Run',
  'Run Payout' => 'Run Payout',
  'Run Rebill Manually' => 'Run Rebill Manually',
  'Run Reports' => 'Run Reports',
  'SMTP' => 'SMTP',
  'SMTP Hostname' => 'SMTP Hostname',
  'SMTP Hostname is required if you have enabled SMTP method' => 'SMTP Hostname is required if you have enabled SMTP method',
  'SMTP Password' => 'SMTP Password',
  'SMTP Port' => 'SMTP Port',
  'SMTP Security' => 'SMTP Security',
  'SMTP Username' => 'SMTP Username',
  'SQL (could not be used for multi-select and checkbox fields)' => 'SQL (could not be used for multi-select and checkbox fields)',
  'SQL Date Format' => 'SQL Date Format',
  'SQL field type' => 'SQL field type',
  'Sales' => 'Sales',
  'Sales Statistic' => 'Sales Statistic',
  'Salt' => 'Salt',
  'Save As Preset' => 'Save As Preset',
  'Save This Search' => 'Save This Search',
  'Saved Credit Cards' => 'Saved Credit Cards',
  'Saved Echecks' => 'Saved Echecks',
  'Saved Reports' => 'Saved Reports',
  'Saved Search' => 'Saved Search',
  'Scaling' => 'Scaling',
  'Second Period' => 'Second Period',
  'Second Price' => 'Second Price',
  'Second Price
price that must be billed for second and
the following periods of subscription' => 'Second Price
price that must be billed for second and
the following periods of subscription',
  'Secret Code
if form is not choosen as default, this code
(inside URL) will be necessary to open form' => 'Secret Code
if form is not choosen as default, this code
(inside URL) will be necessary to open form',
  'Secure Root URL
secure URL, usually %s' => 'Secure Root URL
secure URL, usually %s',
  'Select (Multiple Values)' => 'Select (Multiple Values)',
  'Select (Single Value)' => 'Select (Single Value)',
  'Select Action of Element' => 'Select Action of Element',
  'Select Product(s)
if nothing selected - all products' => 'Select Product(s)
if nothing selected - all products',
  'Select Type of Element' => 'Select Type of Element',
  'Select a plugin' => 'Select a plugin',
  'Select option' => 'Select option',
  'Selected for E-Mailing' => 'Selected for E-Mailing',
  'Self Service' => 'Self Service',
  'Self-Service Store Configuration' => 'Self-Service Store Configuration',
  'Semicolon' => 'Semicolon',
  'Send' => 'Send',
  'Send Autoclose Notification to User
aMember will email an autoresponder to user
when ticket is closed due to inactivity' => 'Send Autoclose Notification to User
aMember will email an autoresponder to user
when ticket is closed due to inactivity',
  'Send Cancel Notifications to Admin
send email to admin when recurring subscription cancelled by member' => 'Send Cancel Notifications to Admin
send email to admin when recurring subscription cancelled by member',
  'Send Cancel Notifications to User' => 'Send Cancel Notifications to User',
  'Send Copy of All Admin Notifications' => 'Send Copy of All Admin Notifications',
  'Send Credit Card Rebill Stats to Admin
Credit Card Rebill Stats will be sent to Admin daily. It works for payment processors like Authorize.Net and PayFlow Pro only' => 'Send Credit Card Rebill Stats to Admin
Credit Card Rebill Stats will be sent to Admin daily. It works for payment processors like Authorize.Net and PayFlow Pro only',
  'Send E-Mail Message' => 'Send E-Mail Message',
  'Send E-Mail Messages' => 'Send E-Mail Messages',
  'Send E-Mail if customer has subscription (required)' => 'Send E-Mail if customer has subscription (required)',
  'Send E-Mail only if customer has no subscription (optional)' => 'Send E-Mail only if customer has no subscription (optional)',
  'Send E-Mail when subscription expires (required)' => 'Send E-Mail when subscription expires (required)',
  'Send New E-Mail' => 'Send New E-Mail',
  'Send Notification When Ticket is Assigned to Admin
aMember will email a notification to admin
each time ticket is assigned to him' => 'Send Notification When Ticket is Assigned to Admin
aMember will email a notification to admin
each time ticket is assigned to him',
  'Send Notification about New Messages to Admin
aMember will email a notification to admin
each time user responds to a ticket' => 'Send Notification about New Messages to Admin
aMember will email a notification to admin
each time user responds to a ticket',
  'Send Notification about New Messages to Customer
aMember will email a notification to user
each time admin responds to a user ticket' => 'Send Notification about New Messages to Customer
aMember will email a notification to user
each time admin responds to a user ticket',
  'Send Notification to Admin When Profile is Changed
admin will receive an email if user has changed profile
' => 'Send Notification to Admin When Profile is Changed
admin will receive an email if user has changed profile
',
  'Send Registration E-Mail
once customer completes signup form (before payment)' => 'Send Registration E-Mail
once customer completes signup form (before payment)',
  'Send Registration E-Mail to this user' => 'Send Registration E-Mail to this user',
  'Send Signup E-Mail
once FIRST subscripton is completed' => 'Send Signup E-Mail
once FIRST subscripton is completed',
  'Send Test E-Mail' => 'Send Test E-Mail',
  'Send message' => 'Send message',
  'Send reports to my email' => 'Send reports to my email',
  'Sender' => 'Sender',
  'Sending Test E-Mail...' => 'Sending Test E-Mail...',
  'Sending e-mail (sent to %d from %d)' => 'Sending e-mail (sent to %d from %d)',
  'Sent' => 'Sent',
  'Session Storage' => 'Session Storage',
  'Set the following admin as owner of ticket' => 'Set the following admin as owner of ticket',
  'Setting which defines how video is scaled on the video screen. Available options are:

                <strong>fit</strong>: Fit to window by preserving the aspect ratio encoded in the file\'s metadata.
                <strong>half</strong>: Half-size (preserves aspect ratio)
                <strong>orig</strong>: Use the dimensions encoded in the file. If the video is too big for the available space, the video is scaled using the \'fit\' option.
                <strong>scale</strong>: Scale the video to fill all available space. Ignores the dimensions in the metadata. This is the default setting.
                ' => 'Setting which defines how video is scaled on the video screen. Available options are:

                <strong>fit</strong>: Fit to window by preserving the aspect ratio encoded in the file\'s metadata.
                <strong>half</strong>: Half-size (preserves aspect ratio)
                <strong>orig</strong>: Use the dimensions encoded in the file. If the video is too big for the available space, the video is scaled using the \'fit\' option.
                <strong>scale</strong>: Scale the video to fill all available space. Ignores the dimensions in the metadata. This is the default setting.
                ',
  'Setup/Configuration' => 'Setup/Configuration',
  'Setup/Configuration : ' => 'Setup/Configuration : ',
  'Shopping Cart Settings' => 'Shopping Cart Settings',
  'Should be greater than 0' => 'Should be greater than 0',
  'Show Error Message' => 'Show Error Message',
  'Show Gravatars in Ticket Conversation' => 'Show Gravatars in Ticket Conversation',
  'Show Search Function in FAQ' => 'Show Search Function in FAQ',
  'Show invoices with selected statuses' => 'Show invoices with selected statuses',
  'Signature Text
You can use the following placeholders %name_f%, %name_l%
it will be expanded to first and last name of admin in operation' => 'Signature Text
You can use the following placeholders %name_f%, %name_l%
it will be expanded to first and last name of admin in operation',
  'Signup Form Configuration' => 'Signup Form Configuration',
  'Signup Info' => 'Signup Info',
  'Signup Messages' => 'Signup Messages',
  'Signups' => 'Signups',
  'Site Title' => 'Site Title',
  'Site is temporarily disabled for maintenance' => 'Site is temporarily disabled for maintenance',
  'Size' => 'Size',
  'Size of input field' => 'Size of input field',
  'Skip' => 'Skip',
  'Skip First Line' => 'Skip First Line',
  'Skip Index Page if User is Logged-in' => 'Skip Index Page if User is Logged-in',
  'Skip Line if Exist User with Same Login' => 'Skip Line if Exist User with Same Login',
  'So you can manually mark payment as refunded or charged-back. Access will be revoked immediately.' => 'So you can manually mark payment as refunded or charged-back. Access will be revoked immediately.',
  'Software version info' => 'Software version info',
  'Sometimes, after configuration errors and as result of software problems, aMember users database
and third-party scripts databases becomes out of sync. Then you can run rebuild process manually
to get databases fixed.' => 'Sometimes, after configuration errors and as result of software problems, aMember users database
and third-party scripts databases becomes out of sync. Then you can run rebuild process manually
to get databases fixed.',
  'Sort' => 'Sort',
  'Sort Order' => 'Sort Order',
  'Sort order' => 'Sort order',
  'Source' => 'Source',
  'Space' => 'Space',
  'Specified folder is already protected. Please alter existing record or choose another folder.' => 'Specified folder is already protected. Please alter existing record or choose another folder.',
  'Standard PHP Sessions' => 'Standard PHP Sessions',
  'Start Date' => 'Start Date',
  'Start Date Calculation
rules for subscription start date calculation.
MAX date from alternatives will be chosen.
This settings has no effect for recurring subscriptions' => 'Start Date Calculation
rules for subscription start date calculation.
MAX date from alternatives will be chosen.
This settings has no effect for recurring subscriptions',
  'Start and Expiration Dates' => 'Start and Expiration Dates',
  'Started' => 'Started',
  'State Title' => 'State Title',
  'Step %d of %d' => 'Step %d of %d',
  'Stop Recurring' => 'Stop Recurring',
  'String' => 'String',
  'Subaffiliate' => 'Subaffiliate',
  'Subject is required' => 'Subject is required',
  'Submitting...' => 'Submitting...',
  'Subscription' => 'Subscription',
  'Subscription Begin Date' => 'Subscription Begin Date',
  'Subscription Expiration (or next rebill date if subscription is recurring)' => 'Subscription Expiration (or next rebill date if subscription is recurring)',
  'Subscription Expire Date' => 'Subscription Expire Date',
  'Subscription field should have numeric value which represent subscription in current installation. You can find these values at %sManage Products%s page, column #.' => 'Subscription field should have numeric value which represent subscription in current installation. You can find these values at %sManage Products%s page, column #.',
  'Super Admin' => 'Super Admin',
  'Surcharge' => 'Surcharge',
  'Surcharge
to be additionally charged when customer moves [From]->[To] plan
aMember will not charge First Price on upgrade, use Surcharge instead' => 'Surcharge
to be additionally charged when customer moves [From]->[To] plan
aMember will not charge First Price on upgrade, use Surcharge instead',
  'System Info' => 'System Info',
  'Table' => 'Table',
  'Tables to Purge' => 'Tables to Purge',
  'Tabulation' => 'Tabulation',
  'Target User
move information to' => 'Target User
move information to',
  'Tax Id' => 'Tax Id',
  'Template' => 'Template',
  'Template
alternative template for signup page' => 'Template
alternative template for signup page',
  'Template
alternative template for this page' => 'Template
alternative template for this page',
  'Template
alternative template for this video' => 'Template
alternative template for this video',
  'Terms Text
automatically calculated if empty' => 'Terms Text
automatically calculated if empty',
  'Test E-Mail Settings' => 'Test E-Mail Settings',
  'Text' => 'Text',
  'Text (unlimited length string/data)' => 'Text (unlimited length string/data)',
  'Text E-Mail Unsubscribe Link
%link% will be replaced to actual unsubscribe URL' => 'Text E-Mail Unsubscribe Link
%link% will be replaced to actual unsubscribe URL',
  'Text Link' => 'Text Link',
  'Text Links' => 'Text Links',
  'Text in your file should be encoded in UTF-8 encoding.' => 'Text in your file should be encoded in UTF-8 encoding.',
  'TextArea' => 'TextArea',
  'The action has been repeated, ipn script response [%s]' => 'The action has been repeated, ipn script response [%s]',
  'The amount of video data (in seconds) which should be loaded into Flowplayer\'s memory in advance of playback commencing.' => 'The amount of video data (in seconds) which should be loaded into Flowplayer\'s memory in advance of playback commencing.',
  'The code [%s] is already used by signup form #%s, please choose another code' => 'The code [%s] is already used by signup form #%s, please choose another code',
  'The password is entered incorrectly' => 'The password is entered incorrectly',
  'There is %s users with same registration IP Address' => 'There is %s users with same registration IP Address',
  'This IP is Banned' => 'This IP is Banned',
  'This code can be inserted into any HTML page on your website or into any WordPress post or page' => 'This code can be inserted into any HTML page on your website or into any WordPress post or page',
  'This email template is empty in given language.
Press [Copy] to copy template from default language [English]
Press [Skip] to type it manually from scratch.' => 'This email template is empty in given language.
Press [Copy] to copy template from default language [English]
Press [Skip] to type it manually from scratch.',
  'This field is required for choosen action' => 'This field is required for choosen action',
  'This field is requred' => 'This field is requred',
  'This is necessary to run aMember CP -> Rebuild DB -> Rebuild Core and Invoice database after import' => 'This is necessary to run aMember CP -> Rebuild DB -> Rebuild Core and Invoice database after import',
  'This user is not a reseller' => 'This user is not a reseller',
  'Thresehold Date' => 'Thresehold Date',
  'Ticket Categories' => 'Ticket Categories',
  'Ticket#' => 'Ticket#',
  'Tickets Assigned to Me' => 'Tickets Assigned to Me',
  'Tier' => 'Tier',
  'Title
displayed to customers' => 'Title
displayed to customers',
  'Title of Element' => 'Title of Element',
  'Title of Report for your Reference' => 'Title of Report for your Reference',
  'To' => 'To',
  'To Product' => 'To Product',
  'To order this product user must have an
when user orders this subscription, it will be checked
that user has one from the following subscriptions' => 'To order this product user must have an
when user orders this subscription, it will be checked
that user has one from the following subscriptions',
  'To restore the aMember database please pick a previously saved aMember Pro backup.' => 'To restore the aMember database please pick a previously saved aMember Pro backup.',
  'To save a spreadsheet as a comma separate value (CSV) file (OpenOffice):' => 'To save a spreadsheet as a comma separate value (CSV) file (OpenOffice):',
  'To starting sharing media files, you have to download either free or commercial version of <a href="http://flowplayer.org/">FlowPlayer</a><br />' => 'To starting sharing media files, you have to download either free or commercial version of <a href="http://flowplayer.org/">FlowPlayer</a><br />',
  'To use coupon from this batch user must have an
when user uses coupon, it will be checked
that user has one from the following subscriptions' => 'To use coupon from this batch user must have an
when user uses coupon, it will be checked
that user has one from the following subscriptions',
  'To verify import result go to %sBrowse Users%s' => 'To verify import result go to %sBrowse Users%s',
  'Top Margin
How much [pt] skip from top of template before start to output invoice
1 pt = 0.352777 mm' => 'Top Margin
How much [pt] skip from top of template before start to output invoice
1 pt = 0.352777 mm',
  'Total Paid' => 'Total Paid',
  'Total to Pay' => 'Total to Pay',
  'Trace' => 'Trace',
  'Traditional .htpasswd' => 'Traditional .htpasswd',
  'Transactions Log' => 'Transactions Log',
  'Transactions with this coupon:' => 'Transactions with this coupon:',
  'Translation' => 'Translation',
  'Trying to copy from unexisting template : %s' => 'Trying to copy from unexisting template : %s',
  'Two Columns' => 'Two Columns',
  'URL' => 'URL',
  'URL must be specified without trailing slash' => 'URL must be specified without trailing slash',
  'URL must start from %s or %s' => 'URL must start from %s or %s',
  'USA (Letter)' => 'USA (Letter)',
  'Unable to cancel subscription' => 'Unable to cancel subscription',
  'Unable to change rebill date' => 'Unable to change rebill date',
  'Unable to load widget: %s' => 'Unable to load widget: %s',
  'Unable to restart subscription' => 'Unable to restart subscription',
  'Unknown Widget with Id [%s]' => 'Unknown Widget with Id [%s]',
  'Unknown mode [%s] in %s->%s' => 'Unknown mode [%s] in %s->%s',
  'Unknown protection method' => 'Unknown protection method',
  'Unknown report display type [%s]' => 'Unknown report display type [%s]',
  'Unlock' => 'Unlock',
  'Unpack Upgrades' => 'Unpack Upgrades',
  'Update Error' => 'Update Error',
  'Update License Information' => 'Update License Information',
  'Update User if Exist User with Same Login' => 'Update User if Exist User with Same Login',
  'Upgrade' => 'Upgrade',
  'Upgrade Database' => 'Upgrade Database',
  'Upgrade Download Problem' => 'Upgrade Download Problem',
  'Upgrade Finished' => 'Upgrade Finished',
  'Upgrade From' => 'Upgrade From',
  'Upgrade To' => 'Upgrade To',
  'Upload' => 'Upload',
  'Upload file [email-templates.xml]' => 'Upload file [email-templates.xml]',
  'Uploaded file is not valid aMember Pro backup' => 'Uploaded file is not valid aMember Pro backup',
  'Upsell - Replace Product from [Conditions] field' => 'Upsell - Replace Product from [Conditions] field',
  'Upsell Configuration' => 'Upsell Configuration',
  'Upsell Paths' => 'Upsell Paths',
  'Use Custom Settings' => 'Use Custom Settings',
  'Use E-Mail Throttle Queue' => 'Use E-Mail Throttle Queue',
  'Use External Cron' => 'Use External Cron',
  'Use Global Settings' => 'Use Global Settings',
  'Use aMember3 Compatible Urls
Enable old style urls (ex.: signup.php, profile.php)
Usefull only after upgrade from aMember v3 to keep old links working.
' => 'Use aMember3 Compatible Urls
Enable old style urls (ex.: signup.php, profile.php)
Usefull only after upgrade from aMember v3 to keep old links working.
',
  'Use first %d IP address octets to determine different IP (%s)' => 'Use first %d IP address octets to determine different IP (%s)',
  'Use the following product for demo users' => 'Use the following product for demo users',
  'Use this %slink%s to delete data from aMember v4 database and use clean database for import' => 'Use this %slink%s to delete data from aMember v4 database and use clean database for import',
  'Used For' => 'Used For',
  'Used Rules' => 'Used Rules',
  'Useful for invoices with non-Latin symbols' => 'Useful for invoices with non-Latin symbols',
  'User' => 'User',
  'User Access' => 'User Access',
  'User Coupon Usage Count
how many times a coupon code can be used by customer' => 'User Coupon Usage Count
how many times a coupon code can be used by customer',
  'User Email' => 'User Email',
  'User IP address' => 'User IP address',
  'User Id' => 'User Id',
  'User Invoices' => 'User Invoices',
  'User Pages Theme' => 'User Pages Theme',
  'User Session Lifetime (minutes)
default - 120' => 'User Session Lifetime (minutes)
default - 120',
  'User currently has access to the following products' => 'User currently has access to the following products',
  'User had access to the following products' => 'User had access to the following products',
  'User has %s Pending Invoices' => 'User has %s Pending Invoices',
  'User is locked' => 'User is locked',
  'User is not approved' => 'User is not approved',
  'User notification' => 'User notification',
  'User-Affiliate Relation Lifetime
how long (in days) calculate commission for referred affiliate (default: 0 - forever)' => 'User-Affiliate Relation Lifetime
how long (in days) calculate commission for referred affiliate (default: 0 - forever)',
  'Username Length' => 'Username Length',
  'Username of Source User
move information from' => 'Username of Source User
move information from',
  'Username or E-mail' => 'Username or E-mail',
  'Username or e-mail address' => 'Username or e-mail address',
  'Users' => 'Users',
  'Users Breakdown' => 'Users Breakdown',
  'Users Report' => 'Users Report',
  'Utilities' => 'Utilities',
  'Valid license key are one-line string,starts with L and ends with X' => 'Valid license key are one-line string,starts with L and ends with X',
  'Validation' => 'Validation',
  'Validation Messages to Customer' => 'Validation Messages to Customer',
  'Value
use % as wildcard mask' => 'Value
use % as wildcard mask',
  'Value must be alpha-numeric' => 'Value must be alpha-numeric',
  'Value must be alphanumeric' => 'Value must be alphanumeric',
  'Values must not be equal' => 'Values must not be equal',
  'VatId' => 'VatId',
  'Verify E-Mail Address On Signup Page
e-mail verification may be enabled for each signup form separately
at aMember CP -> Forms Editor -> Edit, click "configure" on E-Mail brick' => 'Verify E-Mail Address On Signup Page
e-mail verification may be enabled for each signup form separately
at aMember CP -> Forms Editor -> Edit, click "configure" on E-Mail brick',
  'Verify New E-Mail Address On Profile Page
e-mail verification for profile form may be enabled
at aMember CP -> Forms Editor -> Edit, click "configure" on E-Mail brick' => 'Verify New E-Mail Address On Profile Page
e-mail verification for profile form may be enabled
at aMember CP -> Forms Editor -> Edit, click "configure" on E-Mail brick',
  'Version' => 'Version',
  'Version Info' => 'Version Info',
  'Versions for [%s]' => 'Versions for [%s]',
  'Video Player' => 'Video Player',
  'Video for Non User
this video will be shown instead of actual video in case of non-user try to access protected video content. %sThis video will be public and do not require any login/password%s. You can add new video %shere%s' => 'Video for Non User
this video will be shown instead of actual video in case of non-user try to access protected video content. %sThis video will be public and do not require any login/password%s. You can add new video %shere%s',
  'Video for User without Proper Membership Level
this video will be shown instead of actual video in case of user without proper access try to access protected video content. %sThis video will be public and do not require any login/password%s. You can add new video %shere%s' => 'Video for User without Proper Membership Level
this video will be shown instead of actual video in case of user without proper access try to access protected video content. %sThis video will be public and do not require any login/password%s. You can add new video %shere%s',
  'Video/Audio File
(max upload size %s)
You can use this feature only for video and
audio formats that %ssupported by %s%s' => 'Video/Audio File
(max upload size %s)
You can use this feature only for video and
audio formats that %ssupported by %s%s',
  'View' => 'View',
  'View Coupons' => 'View Coupons',
  'Void Commission' => 'Void Commission',
  'Voided' => 'Voided',
  'WARNING! ALL YOUR CURRENT AMEMBER TABLES
    AND RECORDS WILL BE REPLACED WITH THE CONTENTS OF THE BACKUP!' => 'WARNING! ALL YOUR CURRENT AMEMBER TABLES
    AND RECORDS WILL BE REPLACED WITH THE CONTENTS OF THE BACKUP!',
  'WARNING! All existing e-mail templates will be removed from database!' => 'WARNING! All existing e-mail templates will be removed from database!',
  'WARNING! Once [Merge] button clicked, all invoices, payments, logs
and other information regarding \'Source User\' will be moved
to the \'Target User\' account. \'Source User\' account will be deleted.
There is no way to undo this operation!' => 'WARNING! Once [Merge] button clicked, all invoices, payments, logs
and other information regarding \'Source User\' will be moved
to the \'Target User\' account. \'Source User\' account will be deleted.
There is no way to undo this operation!',
  'We will submit a request to payment system or you will be redirected to payment system page to submit refund request' => 'We will submit a request to payment system or you will be redirected to payment system page to submit refund request',
  'Weekly' => 'Weekly',
  'When logged-in user try to access /amember/index page, he will be redirected to /amember/member' => 'When logged-in user try to access /amember/index page, he will be redirected to /amember/member',
  'Widget with Id [%s] has not config form' => 'Widget with Id [%s] has not config form',
  'Width' => 'Width',
  'Wrong id' => 'Wrong id',
  'Yes, assign category' => 'Yes, assign category',
  'Yes, assign group' => 'Yes, assign group',
  'Yes, do not e-mail this customer for any reasons' => 'Yes, do not e-mail this customer for any reasons',
  'Yes, locked' => 'Yes, locked',
  'Yes, remove category' => 'Yes, remove category',
  'Yes, remove group' => 'Yes, remove group',
  'You can %ssave%s this report for future use. You will be able to add this report to your dashboard or send it to your email periodically.' => 'You can %ssave%s this report for future use. You will be able to add this report to your dashboard or send it to your email periodically.',
  'You can assign some coupon codes to specific user. Only this user will be able to use this coupon.' => 'You can assign some coupon codes to specific user. Only this user will be able to use this coupon.',
  'You can download %sexample&nbsp;file%s.' => 'You can download %sexample&nbsp;file%s.',
  'You can find info regarding pdf invoice customization %shere%s' => 'You can find info regarding pdf invoice customization %shere%s',
  'You can import users from CSV file to aMember.' => 'You can import users from CSV file to aMember.',
  'You can not delete your own account' => 'You can not delete your own account',
  'You can not merge user with itself' => 'You can not merge user with itself',
  'You can not set up exchange rate for past.' => 'You can not set up exchange rate for past.',
  'You can save this search for later usage, just give it a descriptive name and press "Store" button.' => 'You can save this search for later usage, just give it a descriptive name and press "Store" button.',
  'You have currently choosed the following users for e-mail to:' => 'You have currently choosed the following users for e-mail to:',
  'You have generated %d demo products and %d demo customers' => 'You have generated %d demo products and %d demo customers',
  'You have imported %d customers' => 'You have imported %d customers',
  'You have license keys from past versions of aMember, please replace it with latest, one-line keys' => 'You have license keys from past versions of aMember, please replace it with latest, one-line keys',
  'You have no permissions to perform requested operation' => 'You have no permissions to perform requested operation',
  'You have not added any products, your signup forms will not work until you <a class="link" href="' => 'You have not added any products, your signup forms will not work until you <a class="link" href="',
  'Your Password
enter your current password
in order to edit admin record' => 'Your Password
enter your current password
in order to edit admin record',
  'Zip Code' => 'Zip Code',
  '[From] and [To] billing plans must not be equal' => '[From] and [To] billing plans must not be equal',
  'aMember Database (default)' => 'aMember Database (default)',
  'aMember database has been successfully restored from backup.' => 'aMember database has been successfully restored from backup.',
  'aMember does not respect category hierarchy. Each category is absolutely independent. You can use hierarchy only to organize your categories.' => 'aMember does not respect category hierarchy. Each category is absolutely independent. You can use hierarchy only to organize your categories.',
  'aMember does not respect group hierarchy. Each group is absolutely independent. You can use hierarchy only to organize your groups.' => 'aMember does not respect group hierarchy. Each group is absolutely independent. You can use hierarchy only to organize your groups.',
  'aMember generate payout reports automatically according your settings %shere%s. Please note user without defined valid payout method will not be included to this payout report. They should define it first in his member area.' => 'aMember generate payout reports automatically according your settings %shere%s. Please note user without defined valid payout method will not be included to this payout report. They should define it first in his member area.',
  'aMember generate payout reports automatically according your settings below. Then you can use these reports to make real payout. You can find list of payout reports %shere%s. User without defined valid payout method will not be included to payout report until he fill payout method in member area.' => 'aMember generate payout reports automatically according your settings below. Then you can use these reports to make real payout. You can find list of payout reports %shere%s. User without defined valid payout method will not be included to payout report until he fill payout method in member area.',
  'aMember will look for templates in [application/default/views/] folder
and in theme\'s [/] folder
and template filename must start with [layout]' => 'aMember will look for templates in [application/default/views/] folder
and in theme\'s [/] folder
and template filename must start with [layout]',
  'aMember will look for templates in [application/default/views/signup/] folder
and in theme\'s [signup/] folder
and template filename must start with [signup]' => 'aMember will look for templates in [application/default/views/signup/] folder
and in theme\'s [signup/] folder
and template filename must start with [signup]',
  'access log table (used by admin only)' => 'access log table (used by admin only)',
  'add category' => 'add category',
  'admin log table (used by admin only)' => 'admin log table (used by admin only)',
  'after' => 'after',
  'allow max' => 'allow max',
  'allow user to change quantity' => 'allow user to change quantity',
  'although you can enable this functionality only for selected products' => 'although you can enable this functionality only for selected products',
  'at' => 'at',
  'at ' => 'at ',
  'browse' => 'browse',
  'change' => 'change',
  'check expired subscriptions too' => 'check expired subscriptions too',
  'collapse details' => 'collapse details',
  'created at' => 'created at',
  'days after expiration' => 'days after expiration',
  'days before expiration' => 'days before expiration',
  'days before rebilling' => 'days before rebilling',
  'do not show disabled products' => 'do not show disabled products',
  'do not show pending invoices' => 'do not show pending invoices',
  'do not show refunded payments' => 'do not show refunded payments',
  'does not send zero autoresponder for this access record' => 'does not send zero autoresponder for this access record',
  'don\'t enable it if you have huge users base already' => 'don\'t enable it if you have huge users base already',
  'downloads within' => 'downloads within',
  'during subscription period' => 'during subscription period',
  'error_log table (used by admin only)' => 'error_log table (used by admin only)',
  'expand details' => 'expand details',
  'filter' => 'filter',
  'first paid at' => 'first paid at',
  'for dispaying on signup and profile editing screen (for user)' => 'for dispaying on signup and profile editing screen (for user)',
  'hours' => 'hours',
  'if code is present, products will be hidden in shopping cart and this code is required to see these products' => 'if code is present, products will be hidden in shopping cart and this code is required to see these products',
  'if customer uses more than' => 'if customer uses more than',
  'if user enters wrong password' => 'if user enters wrong password',
  'if you are unsure, choose first type (string)' => 'if you are unsure, choose first type (string)',
  'immediately after subscription is started' => 'immediately after subscription is started',
  'keep it empty to use any products' => 'keep it empty to use any products',
  'leave it empty in case if you want to show all invoices' => 'leave it empty in case if you want to show all invoices',
  'leave it empty in case of you want this item be available for all users' => 'leave it empty in case of you want this item be available for all users',
  'login, email or name' => 'login, email or name',
  'make it public' => 'make it public',
  'manually approve all new invoices' => 'manually approve all new invoices',
  'manually approve all new users (first payment)' => 'manually approve all new users (first payment)',
  'minimal commission amount earned by affiliate to include it to payout report' => 'minimal commission amount earned by affiliate to include it to payout report',
  'minutes %sdeny access for user%s and do the following' => 'minutes %sdeny access for user%s and do the following',
  'must be a number in format 99 or 99.99' => 'must be a number in format 99 or 99.99',
  'must be equal or greather than 0' => 'must be equal or greather than 0',
  'must be equal or greather than 0.0' => 'must be equal or greather than 0.0',
  'must be greater than 0' => 'must be greater than 0',
  'new' => 'new',
  'next 30 days' => 'next 30 days',
  'none' => 'none',
  'notification will be sent in case of one of selected payment system was used for invoice' => 'notification will be sent in case of one of selected payment system was used for invoice',
  'notification will be sent in case of one of selected products exits in invoice' => 'notification will be sent in case of one of selected products exits in invoice',
  'number of days that should go through before commision is included to payout report' => 'number of days that should go through before commision is included to payout report',
  'on expiration day' => 'on expiration day',
  'open in new window' => 'open in new window',
  'or' => 'or',
  'or %smake access free%s' => 'or %smake access free%s',
  'password should contain at least 2 capital letters, 2 or more numbers and 2 or more special chars' => 'password should contain at least 2 capital letters, 2 or more numbers and 2 or more special chars',
  'put website offline, making it available for admins only' => 'put website offline, making it available for admins only',
  'refund' => 'refund',
  'replace' => 'replace',
  'seconds, he will be forced to wait until next try' => 'seconds, he will be forced to wait until next try',
  'send email to member when he cancels recurring subscription.' => 'send email to member when he cancels recurring subscription.',
  'send email to user in case he has commission but did not define payout method yet.
This email will be sent only once.' => 'send email to user in case he has commission but did not define payout method yet.
This email will be sent only once.',
  'sending' => 'sending',
  'sent successfully' => 'sent successfully',
  'sql field will be added to table structure, common field will not, we recommend you to choose second option' => 'sql field will be added to table structure, common field will not, we recommend you to choose second option',
  'switch to show all records' => 'switch to show all records',
  'switch to show only active records' => 'switch to show only active records',
  'tables restored.' => 'tables restored.',
  'this field will be removed from form if access permission does not match and user will not be able to update this field' => 'this field will be removed from form if access permission does not match and user will not be able to update this field',
  'this item is available for %sall registered customers%s.
click to %smake this item protected%s
%sor %smake this item available without login and registration%s
%s' => 'this item is available for %sall registered customers%s.
click to %smake this item protected%s
%sor %smake this item available without login and registration%s
%s',
  'this item is available for %sall visitors (without log-in and registration) and for all members%s
click to %smake this item protected%s
or %smake log-in required%s
' => 'this item is available for %sall visitors (without log-in and registration) and for all members%s
click to %smake this item protected%s
or %smake log-in required%s
',
  'this message will be shown for customer after purchase.' => 'this message will be shown for customer after purchase.',
  'this option is applied only for video files' => 'this option is applied only for video files',
  'this page will be public and do not require any login/password' => 'this page will be public and do not require any login/password',
  'times within' => 'times within',
  'type part of product name to filter' => 'type part of product name to filter',
  'used to generate email address for users' => 'used to generate email address for users',
  'version' => 'version',
  'void' => 'void',
  'when there is a problem with displaying such symbols in the PDF invoice.' => 'when there is a problem with displaying such symbols in the PDF invoice.',
  'whether loading of clip into player\'s memory should begin straight away. When this is true and autoPlay is false then the clip will automatically stop at the first frame of the video.' => 'whether loading of clip into player\'s memory should begin straight away. When this is true and autoPlay is false then the clip will automatically stop at the first frame of the video.',
  'whether the player should start playback immediately upon loading' => 'whether the player should start playback immediately upon loading',
  'will be included to email to user' => 'will be included to email to user',
  'will be used to construct user-friendly url, in case of you leave it empty aMember will use id of this page to do it' => 'will be used to construct user-friendly url, in case of you leave it empty aMember will use id of this page to do it',
  'will be used to send copy of email notifications to admin you can specify more then one email separated by comma: test@email.com,test1@email.com,test2@email.com' => 'will be used to send copy of email notifications to admin you can specify more then one email separated by comma: test@email.com,test1@email.com,test2@email.com',
  'you can choose from list of currencies supported by paysystems' => 'you can choose from list of currencies supported by paysystems',
  'you can create new pages %shere%s' => 'you can create new pages %shere%s',
  'you can use html markup here' => 'you can use html markup here',
);
