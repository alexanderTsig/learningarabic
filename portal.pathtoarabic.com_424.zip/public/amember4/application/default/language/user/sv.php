<?php 
return array('_'=>'_');