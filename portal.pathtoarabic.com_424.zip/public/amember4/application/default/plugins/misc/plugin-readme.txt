
PLUGIN INSTALLATION

1. Upload plugin code to folder 'amember/application/plugins/protect''
2. Enable plugin at aMember CP -> Setup -> Plugins
3. Visit plugin configuration section aMember CP -> Setup -> [Plugin Name] 
   to configure plugin. Plugin-specific readme is displayed this page at 
   bottom.
