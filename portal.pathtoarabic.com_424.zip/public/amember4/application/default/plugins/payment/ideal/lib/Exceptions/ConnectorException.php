<?php
namespace iDEALConnector\Exceptions;

use Exception;

class ConnectorException extends Exception
{

}
