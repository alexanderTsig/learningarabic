<?php
namespace iDEALConnector\Log;

class LogLevel
{
    const Debug = 0;
    const Error = 1;
}
