Social Coupon Plugin v1.8
Copyright 2012 (c) R Woodgate, Cogmentis Ltd
http://www.cogmentis.com/social-coupon-for-amember-v4/
All Rights Reserved

REQUIREMENTS:
This plugin requires aMember v4.2.13 or higher

INSTALLATION:
1. Simply place this social-coupon folder and files into the  /application/default/plugins/misc folder of your aMember 4 installation.

2. Enable and configure the Social Coupon plugin in aMember CP -> Setup/Configuration -> Plugins

LICENCE:
The purchase of this plugin allows you to install it on any aMember site you personally own. 
The plugin files may not be distributed unless permission is given by author.
This plugin is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 